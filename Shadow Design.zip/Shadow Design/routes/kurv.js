const express = require('express');
const router = express.Router();

// Tilføj pakke til kurv
router.get('/add-to-cart', (req, res) => {
  const { service } = req.query;

  if (!req.session.cart) {
    req.session.cart = [];
  }

  req.session.cart.push(service);
  res.redirect('/kurv');
});

// Vis kurv
router.get('/kurv', (req, res) => {
  const cart = req.session.cart || [];
  res.render('kurv', { cart });
});

// Fjern fra kurv
router.get('/remove-from-cart', (req, res) => {
  const { index } = req.query;

  if (req.session.cart) {
    req.session.cart.splice(index, 1);
  }

  res.redirect('/kurv');
});

// Gå til bestilling
router.get('/kurv/bestil', (req, res) => {
  const cart = req.session.cart || [];
  res.render('ordre', { cart });
});

router.get('/ordre', (req, res) => {
    const cart = req.session.cart || [];
    res.render('ordre', { cart });
  });
  

module.exports = router;
