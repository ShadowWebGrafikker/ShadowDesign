const express = require('express');
const db = require('../models/db');

const router = express.Router();

// Middleware for kun ejer adgang
function onlyOwner(req, res, next) {
  console.log('SESSION BRUGER:', req.session.user); // Tilføjet debug!

  if (!req.session.user || req.session.user.role !== 'ejer') {
    return res.send('Adgang nægtet. Kun ejer kan se denne side.');
  }
  next();
}


// Adminpanel - Se alle brugere
router.get('/admin', onlyOwner, (req, res) => {
  db.all('SELECT * FROM users', [], (err, users) => {
    if (err) {
      console.error(err.message);
      return res.send('Fejl ved hentning af brugere');
    }
    res.render('admin', { users });
  });
});

// Ændre brugerens rolle
router.post('/admin/change-role', onlyOwner, (req, res) => {
  const { user_id, new_role } = req.body;

  db.run('UPDATE users SET role = ? WHERE id = ?', [new_role, user_id], function(err) {
    if (err) {
      console.error(err.message);
      return res.send('Fejl ved opdatering af rolle');
    }
    res.redirect('/admin');
  });
});

module.exports = router;
