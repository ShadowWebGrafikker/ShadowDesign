// Slet opslag
router.post('/delete-post/:id', (req, res) => {
    if (!req.session.user) return res.redirect('/login');
  
    const user_id = req.session.user.id;
    const post_id = req.params.id;
  
    // Tjek om opslaget tilhører brugeren
    db.get('SELECT * FROM posts WHERE id = ?', [post_id], (err, post) => {
      if (err || !post) return res.send('Opslag ikke fundet');
  
      if (post.user_id !== user_id) {
        return res.send('Du har ikke tilladelse til at slette dette opslag');
      }
  
      // Slet opslaget
      db.run('DELETE FROM posts WHERE id = ?', [post_id], function (err) {
        if (err) {
          console.error(err.message);
          return res.send('Fejl ved sletning');
        }
        res.redirect('/profile');
      });
    });
  });
  