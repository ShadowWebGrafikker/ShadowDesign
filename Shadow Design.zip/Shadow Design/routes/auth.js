const express = require('express');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const path = require('path');
const db = require('../models/db');

const router = express.Router();

// Multer til upload
const storage = multer.diskStorage({
  destination: './uploads',
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

// Registrering
router.get('/register', (req, res) => {
  res.render('register');
});

router.post('/register', upload.single('avatar'), async (req, res) => {
  const { name, email, password } = req.body;
  const avatar = req.file ? req.file.filename : null;

  if (!name || !email || !password) {
    return res.send('Alle felter skal udfyldes');
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  let roles = 'kunde'; // Standardrolle er kunde

  // Hvis email matcher ejerens email, bliver brugeren ejer
  if (email === 'WebsiteCreate@outlook.dk') {
    roles = 'ejer,admin,grafik designer'; // Ejer får alle roller
  }

  db.run(
    'INSERT INTO users (name, email, password, avatar, roles) VALUES (?, ?, ?, ?, ?)',
    [name, email, hashedPassword, avatar, roles],
    function (err) {
      if (err) {
        console.error(err.message);
        return res.send('Fejl: Brugeren findes allerede');
      }
      res.redirect('/login');
    }
  );
});

// Login
router.get('/login', (req, res) => {
  res.render('login');
});

router.post('/login', (req, res) => {
  const { email, password } = req.body;

  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
    if (err) return res.send('Fejl ved login');
    if (!user) return res.send('Bruger findes ikke');

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.send('Forkert kodeord');

    // Hvis roles er en tekststreng, split den til array
    user.roles = user.roles ? user.roles.split(',') : [];

    req.session.user = user;
    res.redirect('/profile');
  });
});

// Logout
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

module.exports = router;
