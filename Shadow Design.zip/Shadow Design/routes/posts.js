const express = require('express');
const multer = require('multer');
const path = require('path');
const db = require('../models/db');

const router = express.Router();

// Multer til upload
const storage = multer.diskStorage({
  destination: './uploads',
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

// Vis alle opslag på forsiden
router.get('/', (req, res) => {
  db.all('SELECT posts.*, users.name, users.avatar FROM posts JOIN users ON posts.user_id = users.id ORDER BY posts.id DESC', [], (err, posts) => {
    if (err) {
      console.error(err.message);
      return res.send('Fejl ved hentning af opslag');
    }
    res.render('index', { posts, user: req.session.user });
  });
});

// Vis profilside
router.get('/profile', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/login');
  }

  const userId = req.session.user.id;

  db.all('SELECT * FROM posts WHERE user_id = ?', [userId], (err, posts) => {
    if (err) {
      console.error(err.message);
      return res.send('Fejl ved hentning af dine opslag');
    }
    res.render('profile', { posts, user: req.session.user });
  });
});

// Opret nyt opslag
router.get('/opret', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  res.render('new-post');
});

router.post('/opret', upload.single('image'), (req, res) => {
  if (!req.session.user) {
    return res.redirect('/login');
  }

  const { title, description } = req.body;
  const image = req.file ? req.file.filename : null;
  const userId = req.session.user.id;

  if (!title || !description) {
    return res.send('Alle felter skal udfyldes');
  }

  db.run('INSERT INTO posts (title, description, image, user_id, likes) VALUES (?, ?, ?, ?, ?)', 
    [title, description, image, userId, 0], 
    function(err) {
      if (err) {
        console.error(err.message);
        return res.send('Fejl ved oprettelse af opslag');
      }
      res.redirect('/profile');
    });
});

// Slet opslag
router.get('/posts/slet/:id', (req, res) => {
  const id = req.params.id;

  db.run('DELETE FROM posts WHERE id = ?', [id], (err) => {
    if (err) {
      console.error(err.message);
      return res.send('Fejl ved sletning af opslag');
    }
    res.redirect('/profile');
  });
});

// Like opslag
router.get('/posts/like/:id', (req, res) => {
  const id = req.params.id;

  db.run('UPDATE posts SET likes = likes + 1 WHERE id = ?', [id], (err) => {
    if (err) {
      console.error(err.message);
      return res.send('Fejl ved like af opslag');
    }
    res.redirect('back');
  });
});

// Portfolio side
router.get('/portfolio', (req, res) => {
  db.all(`
    SELECT posts.*, users.name, users.avatar 
    FROM posts 
    JOIN users ON posts.user_id = users.id 
    WHERE users.role = 'grafik designer'
    ORDER BY posts.id DESC
  `, [], (err, posts) => {
    if (err) {
      console.error(err.message);
      return res.send('Fejl ved hentning af portfolio opslag');
    }
    res.render('portfolio', { posts: posts });
  });
});


// Priser side
router.get('/priser', (req, res) => {
  res.render('priser');
});

// Om mig side
router.get('/om-mig', (req, res) => {
  res.render('om-mig');
});

// Kontakt side
router.get('/kontakt', (req, res) => {
  res.render('kontakt');
});

module.exports = router;
